import React, { useState } from 'react';
import { Skull, Home, Search, PlusSquare, Heart, User, MessageCircle, Bookmark, MoreHorizontal, Share, BadgeCheck, Crown, Sparkles } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const mockPosts = [
  {
    id: 1,
    user: {
      username: 'hunter_elite',
      avatar: 'https://images.unsplash.com/photo-1583864697784-a0efc8379f70?w=400&h=400&fit=crop',
      isPremium: true,
    },
    image: 'https://images.unsplash.com/photo-1519162808019-7de1683fa2ad?w=1200',
    likes: 1234,
    caption: 'The hunt begins at dawn. #hunting #wilderness #survival',
    comments: 89,
    timestamp: new Date(Date.now() - 3600000),
    isPremiumContent: true,
  },
  {
    id: 2,
    user: {
      username: 'shadow_warrior',
      avatar: 'https://images.unsplash.com/photo-1599032909756-5deb82fea3b0?w=400&h=400&fit=crop',
      isPremium: true,
    },
    image: 'https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=1200',
    likes: 856,
    caption: 'Ready for battle. #warrior #training #strength',
    comments: 45,
    timestamp: new Date(Date.now() - 7200000),
    isPremiumContent: true,
  },
];

const premiumFeatures = [
  'HD Photo Upload',
  'Exclusive Filters',
  'Priority Stories',
  'Custom Themes',
  'Ad-Free Experience',
  'Analytics Dashboard',
  'Extended Video Length',
  'Custom Profile Themes'
];

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [showPremiumBadge, setShowPremiumBadge] = useState(true);

  return (
    <div className="min-h-screen bg-black text-gray-100 pb-16">
      {/* Premium Banner */}
      {showPremiumBadge && (
        <div className="bg-gradient-to-r from-red-900 to-red-600 text-white py-2 px-4 flex items-center justify-center gap-2">
          <Crown className="w-4 h-4" />
          <span className="text-sm">All Premium Features Unlocked!</span>
          <button 
            onClick={() => setShowPremiumBadge(false)}
            className="ml-4 text-xs opacity-75 hover:opacity-100"
          >
            ×
          </button>
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#1a0000] border-b border-red-900 px-4 py-3">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Skull className="w-8 h-8 text-red-600" />
            <h1 className="text-2xl font-bold text-red-600">SakunaGram</h1>
          </div>
          <div className="flex items-center gap-4">
            <Sparkles className="w-6 h-6 text-yellow-500" />
            <Heart className="w-6 h-6 hover:text-red-600 cursor-pointer" />
            <MessageCircle className="w-6 h-6 hover:text-red-600 cursor-pointer" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto py-4 px-4">
        {/* Premium Features Showcase */}
        <div className="bg-gradient-to-r from-red-900/50 to-red-800/50 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Crown className="w-5 h-5 text-yellow-500" />
            <h2 className="text-lg font-semibold">Premium Features (All Unlocked)</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {premiumFeatures.map((feature, index) => (
              <div key={index} className="flex items-center gap-2 text-sm">
                <Sparkles className="w-4 h-4 text-yellow-500" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stories */}
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex flex-col items-center gap-1 min-w-[80px]">
              <div className="w-16 h-16 rounded-full ring-2 ring-red-600 p-1 relative">
                <img
                  src={`https://images.unsplash.com/photo-${1580000000000 + i}?w=200&h=200&fit=crop`}
                  alt="story"
                  className="w-full h-full rounded-full object-cover"
                />
                <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-0.5">
                  <BadgeCheck className="w-3 h-3 text-white" />
                </div>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-xs">user_{i + 1}</span>
                <Crown className="w-3 h-3 text-yellow-500" />
              </div>
            </div>
          ))}
        </div>

        {/* Posts */}
        <div className="space-y-6 mt-6">
          {mockPosts.map(post => (
            <div key={post.id} className="bg-[#1a0000] border border-red-900 rounded-lg overflow-hidden">
              {/* Post Header */}
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={post.user.avatar}
                      alt={post.user.username}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-0.5">
                      <BadgeCheck className="w-3 h-3 text-white" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">{post.user.username}</span>
                    <Crown className="w-4 h-4 text-yellow-500" />
                  </div>
                </div>
                <MoreHorizontal className="w-6 h-6 cursor-pointer" />
              </div>

              {/* Premium Content Badge */}
              {post.isPremiumContent && (
                <div className="bg-gradient-to-r from-red-900 to-red-600 px-4 py-1 flex items-center gap-2 justify-center">
                  <Sparkles className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">Premium Content</span>
                </div>
              )}

              {/* Post Image */}
              <img
                src={post.image}
                alt="post"
                className="w-full aspect-square object-cover"
              />

              {/* Post Actions */}
              <div className="p-4">
                <div className="flex justify-between mb-2">
                  <div className="flex gap-4">
                    <Heart className="w-6 h-6 cursor-pointer hover:text-red-600" />
                    <MessageCircle className="w-6 h-6 cursor-pointer hover:text-red-600" />
                    <Share className="w-6 h-6 cursor-pointer hover:text-red-600" />
                  </div>
                  <Bookmark className="w-6 h-6 cursor-pointer hover:text-red-600" />
                </div>
                <p className="font-semibold">{post.likes.toLocaleString()} likes</p>
                <p className="mt-1">
                  <span className="font-semibold">{post.user.username}</span>{' '}
                  {post.caption}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  View all {post.comments} comments
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {formatDistanceToNow(post.timestamp)} ago
                </p>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-[#1a0000] border-t border-red-900 px-4 py-3">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <Home
            className={`w-6 h-6 cursor-pointer ${
              activeTab === 'home' ? 'text-red-600' : 'hover:text-red-600'
            }`}
            onClick={() => setActiveTab('home')}
          />
          <Search
            className={`w-6 h-6 cursor-pointer ${
              activeTab === 'search' ? 'text-red-600' : 'hover:text-red-600'
            }`}
            onClick={() => setActiveTab('search')}
          />
          <PlusSquare
            className={`w-6 h-6 cursor-pointer ${
              activeTab === 'create' ? 'text-red-600' : 'hover:text-red-600'
            }`}
            onClick={() => setActiveTab('create')}
          />
          <Heart
            className={`w-6 h-6 cursor-pointer ${
              activeTab === 'notifications' ? 'text-red-600' : 'hover:text-red-600'
            }`}
            onClick={() => setActiveTab('notifications')}
          />
          <User
            className={`w-6 h-6 cursor-pointer ${
              activeTab === 'profile' ? 'text-red-600' : 'hover:text-red-600'
            }`}
            onClick={() => setActiveTab('profile')}
          />
        </div>
      </nav>
    </div>
  );
}

export default App;